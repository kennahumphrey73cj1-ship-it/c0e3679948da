// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Scalar point multiply"); }
int main(){
  announce();
  return lionss_run_workload("secp256k1mul");
}
