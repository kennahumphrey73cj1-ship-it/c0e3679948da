// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Measure TLB shootdown");
  std::fflush(stdout);
  return lionss_run_workload("tlb_shootdown");
}
