// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Generate LOD2 impostor"); }
int main(){
  announce();
  return lionss_run_workload("OrcBrawlerLOD2");
}
