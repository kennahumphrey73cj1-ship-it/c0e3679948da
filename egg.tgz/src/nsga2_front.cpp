// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Sort Pareto fronts\n", stdout);
  return lionss_run_workload("nsga2_front");
}
